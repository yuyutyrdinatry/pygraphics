This package will install MacPython 2.5.2 for Mac OS X
10.3 or later for the following 
architecture(s): i386, ppc.

Separate installers are available for older versions
of Mac OS X, see the homepage, below.

Installation requires approximately 108 MB of disk
space, ignore the message that it will take zero bytes.

You must install onto your current boot disk, even
though the installer does not enforce this, otherwise
things will not work.

MacPython consists of the Python programming language
interpreter, plus a set of programs to allow easy
access to it for Mac users (an integrated development
environment, an applet builder), plus a set of pre-built 
extension modules that open up specific Macintosh technologies 
to Python programs (Carbon, AppleScript, Quicktime, more).

The installer puts the applications in "MacPython 2.5" 
in your Applications folder, command-line tools in
/usr/local/bin and the underlying machinery in
/Library/Frameworks/Python.framework.

More information on MacPython can be found at
http://www.cwi.nl/~jack/macpython and
http://pythonmac.org/.  More information on
Python in general can be found at
http://www.python.org.
