This package installs the python documentation at a location
that is useable for pydoc and IDLE. If you have installed Xcode
it will also install a link to the documentation in
/Developer/Documentation/Python
