This package updates the system python installation on
Mac OS X 10.3 to ensure that you can build new python extensions
using that copy of python after installing this version.
