This packages updates your shell profile to make sure that
the MacPython tools are found by your shell in preference of
the system provided Python tools.

If you don't install this package you'll have to add
"/Library/Frameworks/Python.framework/Versions/2.5/bin"
to your PATH by hand.
