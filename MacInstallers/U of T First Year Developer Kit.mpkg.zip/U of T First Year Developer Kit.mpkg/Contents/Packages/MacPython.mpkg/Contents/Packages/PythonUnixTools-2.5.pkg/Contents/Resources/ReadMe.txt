This package installs the unix tools in /usr/local/bin for
compatibility with older releases of MacPython. This package
is not necessary to use MacPython.
