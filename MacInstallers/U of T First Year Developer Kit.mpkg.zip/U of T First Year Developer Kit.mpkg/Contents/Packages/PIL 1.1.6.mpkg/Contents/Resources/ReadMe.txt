Python Imaging Library 1.1.6

A universal binary for Python 2.5
from http://pythonmac.org/packages/

Python Imaging Library home:
http://www.pythonware.com/products/pil/

This package was built with jpeg 6b, png 1.2.12 and freetype 6.3.3
by Russell Owen using bdist_mpkg